
const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');
canvas.width = window.innerWidth;
canvas.height = window.innerHeight;

let health = 20;
let level = 1;
let score = 0;

function updateUI() {
  document.getElementById('health').textContent = 'Health: ' + health;
  document.getElementById('level').textContent = 'Level: ' + level;
  document.getElementById('score').textContent = 'Score: ' + score;
}

function draw() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);

  // Draw stars background
  for (let i = 0; i < 100; i++) {
    ctx.fillStyle = 'white';
    let x = Math.random() * canvas.width;
    let y = Math.random() * canvas.height;
    ctx.fillRect(x, y, 1, 1);
  }

  // Draw player spaceship (triangle)
  ctx.fillStyle = 'blue';
  ctx.beginPath();
  ctx.moveTo(canvas.width / 2, canvas.height - 30);
  ctx.lineTo(canvas.width / 2 - 20, canvas.height);
  ctx.lineTo(canvas.width / 2 + 20, canvas.height);
  ctx.closePath();
  ctx.fill();

  updateUI();
}

function gameLoop() {
  draw();
  requestAnimationFrame(gameLoop);
}

gameLoop();
